# Create your views here.
# def login(request):
#     if request.method == 'POST' :
#         email = request.POST['email']
#         password = request.POST['pass']
#         user = auth.authenticate(email=email, password=password)
#         if user is not None:
#             auth.login(request,user)
#             return redirect('/')
#         else:
#             messages.info(request,'invalid credentials')
# #             return redirect('login')
#     else:
#         return render(request,'login.html')
# def login(request):
#     if request.method == 'POST':
#         email = request.POST['email']
#         password = request.POST['pass']
#         email = request.POST.get('email')
#         password = request.POST.get('password')
#         user = auth.authenticate(email=email,password=password)
#         if user is not None:
#             auth.login(request, user)
#             return redirect('/')
#         else:
#             messages.info(request,'invalid credentials')
#             return redirect('login')
#     else:
#         return render(request,'login.html')
# def register(request):
#     if request.method=='POST':
#         firstname=request.POST['name']
#         email=request.POST['email']
#         username=request.POST['username']
#         password1=request.POST['pass']
#         password2=request.POST["repeat-pass"]

#         if password1==password2:
#             if User.objects.filter(username=username).exists():
#                 messages.info(request,'username taken')
#                 return redirect('register')
#             elif User.objects.filter(email=email).exists():
#                 messages.info(request,'Already have an account.')
#                 return redirect('login')
#             else:
#                 user=User.objects.create_user(first_name=firstname,password=password1,email=email,username=username)
#                 user.save()
#                 subject = 'Travello-account created'
#                 content = 'you have created an account in travello..! heppy surfing..!'
#                 from_address = 'hemaanjaneyulu392@gmail.com'
#                 to_address = [user.email]
#                 send_mail(subject, content, from_address, to_address, fail_silently=False)
#                 return redirect('login')
#         else:
#             messages.info(request,'password miss match')
#             return redirect('register')
#     else:
#         #  return redirect('username.html')
#         return render(request,'register.html')
# def register(request):
#     if request.method == 'POST':
#         first_name = request.POST['first_name']
#         last_name = request.POST['last_name']
#         username = request.POST['username']
#         email = request.POST['email']
#         password1 = request.POST['password1']
#         password2 = request.POST['password2']
#         if password1==password2:
#             if User.objects.filter(username=username).exists():
#                 messages.info(request,'Username already exists')
#                 return redirect('register')
#             elif User.objects.filter(email=email).exists():
#                 messages.info(request,'Email already exists')
#                 return redirect('register')
#             else:
#                 user = User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
#                 user.save()
#                 messages.info(request,'Registration successful')
#                 return redirect('login')
#         else:
#             messages.info(request,'password not matching')
#             return redirect('register')
#         return redirect('/')
#     else: 
#         return render(request,'register.html')
from django.shortcuts import render,redirect
from django.contrib.auth.models import User,auth
from django.contrib import messages
from django.core.mail import send_mail
from . import views


def login(request):
    if request.method=='POST':
        username=request.POST['username']
        password=request.POST['password']

        user=auth.authenticate(username=username,password=password)

        if user is not None:
            auth.login(request,user)
            return redirect('/')
        
        else:
            messages.info(request,'invalid credentials')
            return redirect('login')
    else :
        return render(request,'login.html')

    
def register(request):
    if request.method=='POST':
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        username=request.POST['username']
        password1=request.POST['password1']
        password2=request.POST['password2']
        email=request.POST['email']
       
        if password1==password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'Username already exists')
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request,'you already have an account')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
                user.save();
                subject = 'Travello-account created'
                content = 'you have created an account in travello..! happy surfing..!'
                from_address = 'hemaanjaneyulu392@gmail.com'
                to_address = [user.email]
                send_mail(subject, content, from_address, to_address, fail_silently=False)
                return redirect('login')

        else:
            messages.info(request,'password not matching')
            return redirect('register')
    else:
        return render(request,'register.html')

def logout(request):
    auth.logout(request)
    return redirect('/')