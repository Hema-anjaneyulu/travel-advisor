from django.urls import path
from . import views
from . views import Details

urlpatterns = [
    path("",views.index,name='index'),
    path("dest/<str:name>/", Details.as_view(), name='dest')
]
