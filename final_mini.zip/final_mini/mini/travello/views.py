from django.shortcuts import render,get_object_or_404
from django.views.generic import ListView
from .models import Destination
# Create your views here.
def index(request):
    dests=Destination.objects.all()
    return render(request,'index.html',{'dests':dests})

class Details(ListView):
    model = Destination
    template_name='mini/destination.html'
    context_object_name = 'destinations'

    def get_queryset(self):
        return Destination.objects.filter(name=self.kwargs.get('name'))
